import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('--- Reports Test ---');

  // Test Maintenance Report Logic
  console.log('\n[Maintenance Report]');
  const categories = await prisma.assetCategory.findMany({
    include: { assets: { include: { maintenanceRequests: true } } }
  });

  categories.forEach(category => {
    let totalRequests = 0;
    let resolvedCount = 0;
    let totalResolutionTimeMs = 0;

    category.assets.forEach(asset => {
      totalRequests += asset.maintenanceRequests.length;
      asset.maintenanceRequests.forEach(req => {
        if (req.status === 'RESOLVED' && req.resolvedAt) {
          resolvedCount++;
          const diff = new Date(req.resolvedAt).getTime() - new Date(req.createdAt).getTime();
          totalResolutionTimeMs += diff;
        }
      });
    });

    const avg = resolvedCount > 0 ? (totalResolutionTimeMs / resolvedCount) / (1000 * 60 * 60) : 0;
    console.log(`- ${category.name}: ${totalRequests} requests, Avg Resolve: ${avg.toFixed(1)} hrs`);
  });

  // Test Utilization Report Logic
  console.log('\n[Utilization Report]');
  const assets = await prisma.asset.findMany({
    where: { isBookable: true },
    include: { bookings: { where: { status: { not: 'CANCELLED' } } } }
  });

  assets.forEach(asset => {
    let totalHoursBooked = 0;
    asset.bookings.forEach(booking => {
      const diff = new Date(booking.endTime).getTime() - new Date(booking.startTime).getTime();
      totalHoursBooked += diff / (1000 * 60 * 60);
    });
    console.log(`- ${asset.name} (${asset.assetTag}): ${asset.bookings.length} bookings, ${totalHoursBooked.toFixed(1)} hrs`);
  });

}

main().catch(console.error).finally(() => prisma.$disconnect());
