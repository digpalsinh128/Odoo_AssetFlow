"use client";

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function NewAssetPage() {
  const router = useRouter();
  const [categories, setCategories] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]); // Assuming we might fetch departments if needed
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    categoryId: '',
    serialNumber: '',
    acquisitionDate: '',
    acquisitionCost: '',
    condition: 'NEW',
    location: '',
    isBookable: false,
    photoUrl: '',
  });

  useEffect(() => {
    // Fetch categories
    fetch('/api/assets/categories')
      .then(res => res.json())
      .then(data => setCategories(data))
      .catch(err => console.error(err));
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const val = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setFormData(prev => ({ ...prev, [name]: val }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/assets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (!res.ok) {
        throw new Error('Failed to create asset');
      }

      const asset = await res.json();
      router.push('/assets');
    } catch (err: any) {
      setError(err.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Register New Asset</h1>

      {error && <div className="bg-red-100 text-red-700 p-4 rounded mb-4">{error}</div>}

      <form onSubmit={handleSubmit} className="bg-white p-6 rounded shadow space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Asset Name *</label>
          <input required type="text" name="name" value={formData.name} onChange={handleChange} className="w-full border p-2 rounded" />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Category *</label>
          <select required name="categoryId" value={formData.categoryId} onChange={handleChange} className="w-full border p-2 rounded">
            <option value="">Select Category</option>
            {categories.map(cat => (
              <option key={cat.id} value={cat.id}>{cat.name}</option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Serial Number</label>
            <input type="text" name="serialNumber" value={formData.serialNumber} onChange={handleChange} className="w-full border p-2 rounded" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Location</label>
            <input type="text" name="location" value={formData.location} onChange={handleChange} className="w-full border p-2 rounded" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Acquisition Date</label>
            <input type="date" name="acquisitionDate" value={formData.acquisitionDate} onChange={handleChange} className="w-full border p-2 rounded" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Acquisition Cost</label>
            <input type="number" step="0.01" name="acquisitionCost" value={formData.acquisitionCost} onChange={handleChange} className="w-full border p-2 rounded" />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Condition</label>
          <select name="condition" value={formData.condition} onChange={handleChange} className="w-full border p-2 rounded">
            <option value="NEW">New</option>
            <option value="GOOD">Good</option>
            <option value="FAIR">Fair</option>
            <option value="POOR">Poor</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Photo URL</label>
          <input type="url" name="photoUrl" value={formData.photoUrl} onChange={handleChange} placeholder="https://..." className="w-full border p-2 rounded" />
        </div>

        <div className="flex items-center gap-2">
          <input type="checkbox" id="isBookable" name="isBookable" checked={formData.isBookable} onChange={handleChange} className="h-4 w-4" />
          <label htmlFor="isBookable" className="text-sm font-medium">Is Bookable (Resource)</label>
        </div>

        <div className="pt-4 border-t">
          <button type="submit" disabled={loading} className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 disabled:opacity-50">
            {loading ? 'Registering...' : 'Register Asset'}
          </button>
        </div>
      </form>
    </div>
  );
}
