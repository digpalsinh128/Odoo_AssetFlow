import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('--- Audit Cycle Test ---');

  // 1. Get a user
  const user = await prisma.user.findFirst();
  if (!user) {
    console.error('No users found');
    return;
  }

  // 2. Create Audit Cycle for Location 'Office A'
  const targetLocation = 'Office A';
  console.log(`\nCreating Audit Cycle for Location: ${targetLocation}`);

  // Fetch directly via DB exactly what the API would do
  const assetsInScope = await prisma.asset.findMany({
    where: { location: { contains: targetLocation } }
  });

  if (assetsInScope.length === 0) {
    console.error(`No assets found in ${targetLocation}`);
    return;
  }

  const cycle = await prisma.$transaction(async (tx) => {
    const newCycle = await tx.auditCycle.create({
      data: {
        scopeLocation: targetLocation,
        startDate: new Date(),
        endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
        status: 'OPEN',
      }
    });

    await tx.auditAuditor.create({
      data: { auditCycleId: newCycle.id, userId: user.id }
    });

    const itemsData = assetsInScope.map(asset => ({
      auditCycleId: newCycle.id,
      assetId: asset.id,
      status: 'PENDING'
    }));
    await tx.auditItem.createMany({ data: itemsData });

    return newCycle;
  });

  // Verify items generated
  const items = await prisma.auditItem.findMany({
    where: { auditCycleId: cycle.id },
    include: { asset: true }
  });

  console.log(`✅ Auto-generated ${items.length} Audit Items matching the location scope.`);
  items.forEach(i => console.log(`   - [${i.status}] ${i.asset.name} (${i.asset.assetTag})`));

  // 3. Mark one item as MISSING, another as VERIFIED
  console.log('\nSimulating Auditor updates...');
  
  if (items.length > 0) {
    await prisma.auditItem.update({
      where: { id: items[0].id },
      data: { status: 'VERIFIED' }
    });
    console.log(`Marked ${items[0].asset.assetTag} as VERIFIED.`);
  }

  if (items.length > 1) {
    await prisma.auditItem.update({
      where: { id: items[1].id },
      data: { status: 'MISSING' }
    });
    console.log(`Marked ${items[1].asset.assetTag} as MISSING.`);
  }

  // 4. Close Audit Cycle
  console.log('\nClosing Audit Cycle...');
  await prisma.$transaction(async (tx) => {
    await tx.auditCycle.update({ where: { id: cycle.id }, data: { status: 'CLOSED' } });

    // API Logic simulation
    const missingItems = await tx.auditItem.findMany({
      where: { auditCycleId: cycle.id, status: 'MISSING' }
    });
    
    for (const item of missingItems) {
      await tx.asset.update({
        where: { id: item.assetId },
        data: { status: 'LOST' }
      });
    }
  });

  // Verify LOST asset
  if (items.length > 1) {
    const checkLostAsset = await prisma.asset.findUnique({ where: { id: items[1].assetId } });
    console.log(`\nChecked Asset ${items[1].asset.assetTag} status in directory: ${checkLostAsset?.status}`);
    if (checkLostAsset?.status === 'LOST') {
      console.log('✅ Cycle close correctly updated missing asset to LOST.');
    } else {
      console.error('❌ Cycle close failed to update missing asset.');
    }
  }

}

main().catch(console.error).finally(() => prisma.$disconnect());
