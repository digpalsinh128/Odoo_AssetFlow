import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category') || '';
    const status = searchParams.get('status') || '';
    const location = searchParams.get('location') || '';
    const departmentId = searchParams.get('departmentId') || '';

    const assets = await prisma.asset.findMany({
      where: {
        ...(search && {
          OR: [
            { assetTag: { contains: search } },
            { name: { contains: search } },
            { serialNumber: { contains: search } }
          ]
        }),
        ...(category && { categoryId: category }),
        ...(status && { status: status as any }),
        ...(location && { location: { contains: location } }),
        ...(departmentId && { departmentId: departmentId }),
      },
      include: {
        category: true,
        department: true,
      },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json(assets);
  } catch (error) {
    console.error('Error fetching assets:', error);
    return NextResponse.json({ error: 'Failed to fetch assets' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json();
    
    // Generate assetTag
    const latestAsset = await prisma.asset.findFirst({
      orderBy: {
        createdAt: 'desc'
      }
    });

    let nextNumber = 1;
    if (latestAsset && latestAsset.assetTag) {
      const match = latestAsset.assetTag.match(/AF-(\d+)/);
      if (match && match[1]) {
        nextNumber = parseInt(match[1], 10) + 1;
      }
    }
    const assetTag = `AF-${nextNumber.toString().padStart(4, '0')}`;

    const newAsset = await prisma.asset.create({
      data: {
        assetTag,
        name: data.name,
        categoryId: data.categoryId,
        serialNumber: data.serialNumber || null,
        acquisitionDate: data.acquisitionDate ? new Date(data.acquisitionDate) : null,
        acquisitionCost: data.acquisitionCost ? parseFloat(data.acquisitionCost) : null,
        condition: data.condition || null,
        location: data.location || null,
        isBookable: Boolean(data.isBookable),
        photoUrl: data.photoUrl || null,
        departmentId: data.departmentId || null,
      }
    });

    await prisma.activityLog.create({
      data: {
        action: 'ASSET_REGISTERED',
        entity: `Asset:${newAsset.id}`,
        details: JSON.stringify({ assetTag: newAsset.assetTag, name: newAsset.name })
      }
    });

    return NextResponse.json(newAsset, { status: 201 });
  } catch (error) {
    console.error('Error creating asset:', error);
    return NextResponse.json({ error: 'Failed to create asset' }, { status: 500 });
  }
}
