"use client";

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';

export default function AssetDetailPage() {
  const params = useParams();
  const id = params.id as string;
  const [asset, setAsset] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch(`/api/assets/${id}`)
      .then(res => {
        if (!res.ok) throw new Error('Asset not found');
        return res.json();
      })
      .then(data => setAsset(data))
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="p-6">Loading asset details...</div>;
  if (error) return <div className="p-6 text-red-600">{error}</div>;
  if (!asset) return <div className="p-6">Asset not found.</div>;

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-8">
      <div>
        <Link href="/assets" className="text-blue-600 hover:underline mb-4 inline-block">&larr; Back to Directory</Link>
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-4">
              {asset.name}
              <span className="bg-gray-100 text-gray-800 text-sm px-3 py-1 rounded-full font-mono">{asset.assetTag}</span>
            </h1>
            <p className="text-gray-500 mt-1">Category: {asset.category?.name}</p>
          </div>
          <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded font-semibold text-sm">
            {asset.status}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 bg-white p-6 rounded shadow">
        <div>
          <h2 className="text-lg font-semibold border-b pb-2 mb-4">Details</h2>
          <div className="space-y-2 text-sm">
            <p><span className="font-medium text-gray-600">Serial Number:</span> {asset.serialNumber || 'N/A'}</p>
            <p><span className="font-medium text-gray-600">Location:</span> {asset.location || 'N/A'}</p>
            <p><span className="font-medium text-gray-600">Condition:</span> {asset.condition || 'N/A'}</p>
            <p><span className="font-medium text-gray-600">Bookable:</span> {asset.isBookable ? 'Yes' : 'No'}</p>
          </div>
        </div>
        <div>
          <h2 className="text-lg font-semibold border-b pb-2 mb-4">Acquisition</h2>
          <div className="space-y-2 text-sm">
            <p><span className="font-medium text-gray-600">Date:</span> {asset.acquisitionDate ? new Date(asset.acquisitionDate).toLocaleDateString() : 'N/A'}</p>
            <p><span className="font-medium text-gray-600">Cost:</span> {asset.acquisitionCost ? `$${asset.acquisitionCost.toFixed(2)}` : 'N/A'}</p>
            <p><span className="font-medium text-gray-600">Department:</span> {asset.department?.name || 'Unassigned'}</p>
          </div>
        </div>
        {asset.photoUrl && (
          <div className="col-span-2">
            <h2 className="text-lg font-semibold border-b pb-2 mb-4">Photo</h2>
            <img src={asset.photoUrl} alt={asset.name} className="max-w-xs rounded shadow" />
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded shadow">
          <h2 className="text-xl font-semibold mb-4">Allocation History</h2>
          {asset.allocations.length === 0 ? (
            <p className="text-gray-500 text-sm">No allocation history.</p>
          ) : (
            <ul className="space-y-4">
              {asset.allocations.map((alloc: any) => (
                <li key={alloc.id} className="border-l-4 border-blue-500 pl-4">
                  <p className="font-medium">{alloc.employee?.name || alloc.department?.name || 'Unknown'}</p>
                  <p className="text-xs text-gray-500">
                    Allocated: {new Date(alloc.allocatedDate).toLocaleDateString()} 
                    {alloc.actualReturnDate && ` • Returned: ${new Date(alloc.actualReturnDate).toLocaleDateString()}`}
                  </p>
                  <p className="text-xs mt-1"><span className="font-medium">Status:</span> {alloc.status}</p>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="bg-white p-6 rounded shadow">
          <h2 className="text-xl font-semibold mb-4">Maintenance History</h2>
          {asset.maintenanceRequests.length === 0 ? (
            <p className="text-gray-500 text-sm">No maintenance history.</p>
          ) : (
            <ul className="space-y-4">
              {asset.maintenanceRequests.map((req: any) => (
                <li key={req.id} className="border-l-4 border-orange-500 pl-4">
                  <p className="font-medium">{req.issue}</p>
                  <p className="text-xs text-gray-500">
                    Raised: {new Date(req.createdAt).toLocaleDateString()} by {req.raisedBy?.name || 'Unknown'}
                  </p>
                  <p className="text-xs mt-1">
                    <span className="font-medium">Status:</span> {req.status} 
                    <span className="ml-2 font-medium">Priority:</span> {req.priority}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
