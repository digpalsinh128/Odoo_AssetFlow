import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding data...');

  const cat1 = await prisma.assetCategory.create({ data: { name: 'Laptops' } });
  const cat2 = await prisma.assetCategory.create({ data: { name: 'Monitors' } });
  const cat3 = await prisma.assetCategory.create({ data: { name: 'Office Furniture' } });

  const dept1 = await prisma.department.create({ data: { name: 'Engineering' } });
  const dept2 = await prisma.department.create({ data: { name: 'HR' } });

  await prisma.asset.createMany({
    data: [
      {
        assetTag: 'AF-0001',
        name: 'MacBook Pro 16"',
        categoryId: cat1.id,
        serialNumber: 'C02XD123',
        acquisitionCost: 2500,
        condition: 'GOOD',
        location: 'Office A',
        isBookable: true,
        departmentId: dept1.id,
      },
      {
        assetTag: 'AF-0002',
        name: 'Dell UltraSharp 27"',
        categoryId: cat2.id,
        serialNumber: 'DL999888',
        acquisitionCost: 400,
        condition: 'NEW',
        location: 'Office A',
        isBookable: false,
        departmentId: dept1.id,
      },
      {
        assetTag: 'AF-0003',
        name: 'Ergonomic Chair',
        categoryId: cat3.id,
        serialNumber: 'EC-001',
        acquisitionCost: 350,
        condition: 'FAIR',
        location: 'Office B',
        isBookable: false,
        departmentId: dept2.id,
      },
      {
        assetTag: 'AF-0004',
        name: 'Projector (Meeting Room 1)',
        categoryId: cat2.id,
        serialNumber: 'PRJ-102',
        acquisitionCost: 800,
        condition: 'GOOD',
        location: 'Meeting Room 1',
        isBookable: true,
      },
      {
        assetTag: 'AF-0005',
        name: 'ThinkPad T14',
        categoryId: cat1.id,
        serialNumber: 'TP555666',
        acquisitionCost: 1200,
        condition: 'GOOD',
        location: 'Office A',
        isBookable: true,
      }
    ]
  });

  console.log('Seeding completed.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
