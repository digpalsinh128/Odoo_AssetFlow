import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('--- Overlap Rule Test ---');

  // 1. Get a bookable asset and a user
  const asset = await prisma.asset.findFirst({ where: { isBookable: true } });
  const user = await prisma.user.findFirst();

  if (!asset || !user) {
    console.error('Missing test data');
    return;
  }

  // Clear existing bookings for clean test
  await prisma.booking.deleteMany({ where: { assetId: asset.id } });

  // 2. Create existing booking: 9:00 - 10:00 (Today)
  const today = new Date();
  today.setHours(0, 0, 0, 0); // Start of today

  const b1Start = new Date(today.getTime() + 9 * 60 * 60 * 1000); // 9:00
  const b1End = new Date(today.getTime() + 10 * 60 * 60 * 1000); // 10:00

  const booking1 = await prisma.booking.create({
    data: {
      assetId: asset.id,
      bookedById: user.id,
      startTime: b1Start,
      endTime: b1End,
      status: 'UPCOMING'
    }
  });

  console.log(`\nExisting Booking created: 09:00 - 10:00 (ID: ${booking1.id})`);

  // --- REJECTED CASE: 9:30 - 10:30 ---
  const b2Start = new Date(today.getTime() + 9.5 * 60 * 60 * 1000); // 9:30
  const b2End = new Date(today.getTime() + 10.5 * 60 * 60 * 1000); // 10:30
  console.log('\n[TEST 1] Attempting to book: 09:30 - 10:30 (Should REJECT)');

  const overlap1 = await prisma.booking.findFirst({
    where: {
      assetId: asset.id,
      status: { not: 'CANCELLED' },
      startTime: { lt: b2End },
      endTime: { gt: b2Start }
    }
  });

  if (overlap1) {
    console.log('✅ REJECTED correctly. Overlap found with ID:', overlap1.id);
  } else {
    console.error('❌ FAILED: Booking was allowed despite overlap.');
  }


  // --- ALLOWED TOUCHING CASE: 10:00 - 11:00 ---
  const b3Start = new Date(today.getTime() + 10 * 60 * 60 * 1000); // 10:00
  const b3End = new Date(today.getTime() + 11 * 60 * 60 * 1000); // 11:00
  console.log('\n[TEST 2] Attempting to book: 10:00 - 11:00 (Should ALLOW - Touching)');

  const overlap2 = await prisma.booking.findFirst({
    where: {
      assetId: asset.id,
      status: { not: 'CANCELLED' },
      startTime: { lt: b3End },
      endTime: { gt: b3Start }
    }
  });

  if (overlap2) {
    console.error('❌ FAILED: Rejected touching booking. Overlap found:', overlap2.id);
  } else {
    console.log('✅ ALLOWED correctly. No overlap detected.');
    // Actually create it
    const booking3 = await prisma.booking.create({
      data: {
        assetId: asset.id,
        bookedById: user.id,
        startTime: b3Start,
        endTime: b3End,
        status: 'UPCOMING'
      }
    });
    console.log(`Created touching booking successfully! (ID: ${booking3.id})`);
  }

}

main().catch(console.error).finally(() => prisma.$disconnect());
