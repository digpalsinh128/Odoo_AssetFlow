import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";



export const metadata: Metadata = {
  title: "AssetFlow",
  description: "Enterprise Asset Management",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`h-full antialiased`}>
      <body className="min-h-screen flex flex-col antialiased selection:bg-blue-100 selection:text-blue-900">
        <header className="bg-white/80 backdrop-blur-md border-b sticky top-0 z-50 shadow-sm">
          <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <div className="text-2xl font-black bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent tracking-tight">
              AssetFlow
            </div>
            <nav className="flex gap-6">
              <a href="/assets" className="text-gray-600 hover:text-blue-600 font-semibold transition-colors">Assets</a>
              <a href="/bookings" className="text-gray-600 hover:text-blue-600 font-semibold transition-colors">Bookings</a>
              <a href="/maintenance" className="text-gray-600 hover:text-blue-600 font-semibold transition-colors">Maintenance</a>
              <a href="/audits" className="text-gray-600 hover:text-blue-600 font-semibold transition-colors">Audits</a>
              <a href="/reports" className="text-gray-600 hover:text-blue-600 font-semibold transition-colors">Reports</a>
              <a href="/activity" className="text-gray-600 hover:text-blue-600 font-semibold transition-colors">Activity Logs</a>
            </nav>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto pb-12">
          {children}
        </main>
      </body>
    </html>
  );
}
